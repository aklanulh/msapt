import React from 'react';

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="navbar-logo">
          <a href="/">Admin Dashboard</a>
        </div>
        <div className="navbar-toggle">
          <button className="toggle-button">
            <span className="bar"></span>
            <span className="bar"></span>
            <span className="bar"></span>
          </button>
        </div>
        <ul className="navbar-menu">
          <li><a href="/dashboard">Manage Dashboard</a></li>
          <li><a href="/tasks">Manage Tasks</a></li>
          <li><a href="/submissions">Manage Submissions</a></li>
          <li><a href="/redeems">Manage Redeems</a></li>
          {/* Tambahkan lebih banyak menu sesuai kebutuhan */}
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
<?php /**PATH D:\laragon\www\adscampaign\resources\views/components/layouts/navigationadmin.blade.php ENDPATH**/ ?>
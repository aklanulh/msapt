<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Submissions')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="flex justify-center items-center bg-gradient-to-br from-purple-200 via-purple-300 to-purple-500 mb-8">
                <div class="overflow-x-auto relative shadow-md sm:rounded-lg">
                    <!-- Table for pending submissions -->
                    <h3 class="text-lg font-semibold mb-4 text-center text-gray-800 dark:text-gray-200">Pending Submissions</h3>
                    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" class="py-3 px-6">Task ID</th>
                                <th scope="col" class="py-3 px-6">Submission URL</th>
                                <th scope="col" class="py-3 px-6">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pendingSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                    <td class="py-4 px-6">
                                        <a href="<?php echo e(route('tasks.show', $submission->task_id)); ?>" class="text-indigo-600 dark:text-indigo-400 hover:underline">
                                            <?php echo e($submission->task_id); ?>

                                        </a>
                                    </td>
                                    <td class="py-4 px-6">
                                        <?php if (isset($component)) { $__componentOriginal81e9d2ae268c88e11768f6576eddadc3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81e9d2ae268c88e11768f6576eddadc3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-link-button','data' => ['href' => $submission->submission_url,'target' => '_blank']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($submission->submission_url),'target' => '_blank']); ?>
                                            View Submission
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81e9d2ae268c88e11768f6576eddadc3)): ?>
<?php $attributes = $__attributesOriginal81e9d2ae268c88e11768f6576eddadc3; ?>
<?php unset($__attributesOriginal81e9d2ae268c88e11768f6576eddadc3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81e9d2ae268c88e11768f6576eddadc3)): ?>
<?php $component = $__componentOriginal81e9d2ae268c88e11768f6576eddadc3; ?>
<?php unset($__componentOriginal81e9d2ae268c88e11768f6576eddadc3); ?>
<?php endif; ?>
                                    </td>
                                    <td class="py-4 px-6"><?php echo e($submission->status); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if($pendingSubmissions->isEmpty()): ?>
                        <p class="text-center text-gray-700 dark:text-gray-300">No submissions awaiting approval.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="flex justify-center items-center bg-gradient-to-br from-purple-200 via-purple-300 to-purple-500">
                <div class="overflow-x-auto relative shadow-md sm:rounded-lg">
                    <!-- Table for approved or rejected submissions -->
                    <h3 class="text-lg font-semibold mb-4 text-center text-gray-800 dark:text-gray-200">Approved/Rejected Submissions</h3>
                    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" class="py-3 px-6">Task ID</th>
                                <th scope="col" class="py-3 px-6">Submission URL</th>
                                <th scope="col" class="py-3 px-6">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $approvedRejectedSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                    <td class="py-4 px-6">
                                        <a href="<?php echo e(route('tasks.show', $submission->task_id)); ?>" class="text-indigo-600 dark:text-indigo-400 hover:underline">
                                            <?php echo e($submission->task_id); ?>

                                        </a>
                                    </td>
                                    <td class="py-4 px-6">
                                        <?php if (isset($component)) { $__componentOriginal81e9d2ae268c88e11768f6576eddadc3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81e9d2ae268c88e11768f6576eddadc3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-link-button','data' => ['href' => $submission->submission_url,'target' => '_blank']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($submission->submission_url),'target' => '_blank']); ?>
                                            View Submission
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81e9d2ae268c88e11768f6576eddadc3)): ?>
<?php $attributes = $__attributesOriginal81e9d2ae268c88e11768f6576eddadc3; ?>
<?php unset($__attributesOriginal81e9d2ae268c88e11768f6576eddadc3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81e9d2ae268c88e11768f6576eddadc3)): ?>
<?php $component = $__componentOriginal81e9d2ae268c88e11768f6576eddadc3; ?>
<?php unset($__componentOriginal81e9d2ae268c88e11768f6576eddadc3); ?>
<?php endif; ?>
                                    </td>
                                    <td class="py-4 px-6"><?php echo e($submission->status); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if($approvedRejectedSubmissions->isEmpty()): ?>
                        <p class="text-center text-gray-700 dark:text-gray-300">No submissions have been approved or rejected.</p>
                    <?php endif; ?>
                </div>
            </div>
            
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\adscampaign\resources\views/submissions/index.blade.php ENDPATH**/ ?>
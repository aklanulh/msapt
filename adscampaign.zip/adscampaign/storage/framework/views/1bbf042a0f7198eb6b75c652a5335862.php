<!-- resources/views/admin/dashboard.blade.php -->

<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <h1 class="mt-4">Admin Dashboard</h1>

        <div class="row">
            <!-- Total Tasks -->
            <div class="col-md-4">
                <a href="<?php echo e(route('admin.tasks.index')); ?>" class="text-decoration-none text-dark">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-tasks"></i>
                            Total Tasks
                        </div>
                        <div class="card-body">
                            <h2 class="card-title"><?php echo e($totalTasks); ?></h2>
                            <p class="card-text">
                                Active: <?php echo e($activeTasks); ?> | Expired: <?php echo e($expiredTasks); ?>

                            </p>
                        </div>
                    </div>
                </a>
            </div>

            <!-- Total Submissions -->
            <div class="col-md-4">
                <a href="<?php echo e(route('admin.submissions')); ?>" class="text-decoration-none text-dark">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-file-alt"></i>
                            Total Submissions
                        </div>
                        <div class="card-body">
                            <h2 class="card-title"><?php echo e($totalSubmissions); ?></h2>
                            <p class="card-text">
                                Pending: <?php echo e($pendingSubmissions); ?> | Approved: <?php echo e($approvedSubmissions); ?> | Rejected: <?php echo e($rejectedSubmissions); ?>

                            </p>
                        </div>
                    </div>
                </a>
            </div>

            <!-- Total Redeems -->
            <div class="col-md-4">
                <a href="<?php echo e(route('admin.redeems')); ?>" class="text-decoration-none text-dark">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-gift"></i>
                            Total Redeems
                        </div>
                        <div class="card-body">
                            <h2 class="card-title"><?php echo e($totalRedeems); ?></h2>
                            <p class="card-text">
                                Pending: <?php echo e($pendingRedeems); ?> | Approved: <?php echo e($approvedRedeems); ?>

                            </p>
                        </div>
                    </div>
                </a>
            </div>
        </div>

        <!-- Recent Tasks -->
        <div class="row">
            <div class="col-md-6">
                <a href="<?php echo e(route('admin.tasks.index')); ?>" class="text-decoration-none text-dark">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-tasks"></i>
                            Recent Tasks
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Description</th>
                                        <th>Points</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $recentTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($task->title); ?></td>
                                            <td><?php echo e(Str::limit($task->description, 40)); ?></td>
                                            <td><?php echo e($task->points); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </a>
            </div>

            <!-- Recent Submissions -->
            <div class="col-md-6">
                <a href="<?php echo e(route('admin.submissions')); ?>" class="text-decoration-none text-dark">
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-file-alt"></i>
                            Recent Submissions
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Task</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $recentSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($submission->user->name); ?></td>
                                            <td><?php echo e($submission->task ? $submission->task->title : 'Task not found'); ?></td>
                                            <td><?php echo e($submission->status); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\adscampaign\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
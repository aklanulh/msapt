<!-- resources/views/admin/submissions.blade.php -->
<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Konten Manage Submissions di sini -->
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <h3>Pending Submissions</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th><a href="<?php echo e(route('admin.submissions', ['sort' => 'user_id', 'direction' => $sortDirection === 'asc' ? 'desc' : 'asc'])); ?>">User ID</a></th>
                            <th><a href="<?php echo e(route('admin.submissions', ['sort' => 'task_id', 'direction' => $sortDirection === 'asc' ? 'desc' : 'asc'])); ?>">Task ID</a></th>
                            <th>Submission URL</th>
                            <th>Status</th>
                            <th>Action</th> <!-- Menambahkan kolom untuk aksi -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($submission->user_id); ?></td>
                                <td><?php echo e($submission->task_id); ?></td>
                                <td>
                                    <a href="<?php echo e($submission->submission_url); ?>" class="btn btn-primary" target="_blank">Open URL</a>
                                </td>
                                <td><?php echo e($submission->status); ?></td>
                                <td>
                                    <form action="<?php echo e(route('approve-submission', $submission->id)); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-success">
                                            <i class="material-icons">check</i>
                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('reject-submission', $submission->id)); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3>Approved/Rejected Submissions</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th><a href="<?php echo e(route('admin.submissions', ['sort' => 'user_id', 'direction' => $sortDirection === 'asc' ? 'desc' : 'asc'])); ?>">User ID</a></th>
                            <th><a href="<?php echo e(route('admin.submissions', ['sort' => 'task_id', 'direction' => $sortDirection === 'asc' ? 'desc' : 'asc'])); ?>">Task ID</a></th>
                            <th>Submission URL</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $actionSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($submission->user_id); ?></td>
                                <td><?php echo e($submission->task_id); ?></td>
                                <td>
                                    <a href="<?php echo e($submission->submission_url); ?>" class="btn btn-primary" target="_blank">Open URL</a>
                                </td>
                                <td><?php echo e($submission->status); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\adscampaign\resources\views/admin/submissions.blade.php ENDPATH**/ ?>